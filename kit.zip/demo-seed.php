<?php
/**
 * Наполнение демо-магазина KNIFE MARKET для WordPress Playground.
 * Запускается один раз при открытии ссылки: тема, категории, товары, фото, страницы, настройки.
 * Все цены и фото — временные, для показа. Реквизиты и юридические тексты — заглушки.
 */
require_once '/wordpress/wp-load.php';
require_once ABSPATH . 'wp-admin/includes/file.php';
require_once ABSPATH . 'wp-admin/includes/media.php';
require_once ABSPATH . 'wp-admin/includes/image.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';

if ( get_option( 'km_demo_seeded' ) ) {
	return;
}
@set_time_limit( 0 );

/* ---------- Помощники ---------- */
function km_sideload( $basename, $title, $parent = 0 ) {
	$src = "/wordpress/demo-media/$basename";
	if ( ! file_exists( $src ) ) {
		return 0;
	}
	$tmp = wp_tempnam( $basename );
	copy( $src, $tmp );
	$id = media_handle_sideload( array( 'name' => $basename, 'tmp_name' => $tmp ), $parent, $title );
	if ( is_wp_error( $id ) ) {
		error_log( 'km sideload ' . $basename . ': ' . $id->get_error_message() );
		return 0;
	}
	update_post_meta( $id, '_wp_attachment_image_alt', $title );
	return (int) $id;
}
function km_p( $text, $class = '' ) {
	$a = $class ? ' {"className":"' . $class . '"}' : '';
	$k = $class ? ' class="' . $class . '"' : '';
	return "<!-- wp:paragraph$a -->\n<p$k>$text</p>\n<!-- /wp:paragraph -->\n\n";
}
function km_h( $text, $level = 2 ) {
	$a = 2 === $level ? '' : ' {"level":' . $level . '}';
	return "<!-- wp:heading$a -->\n<h$level class=\"wp-block-heading\">$text</h$level>\n<!-- /wp:heading -->\n\n";
}
function km_page( $slug, $title, $content, $id = 0 ) {
	$args = array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $slug, 'post_title' => $title, 'comment_status' => 'closed' );
	if ( null !== $content ) {
		$args['post_content'] = $content;
	}
	if ( $id ) {
		$args['ID'] = $id;
		return wp_update_post( wp_slash( $args ) );
	}
	return wp_insert_post( wp_slash( $args ) );
}

/* ---------- Тема, язык, основные настройки ---------- */
switch_theme( 'knife-market' );
update_option( 'WPLANG', 'ru_RU' );
update_option( 'blogname', 'KNIFE MARKET' );
update_option( 'blogdescription', 'Ножи и снаряжение' );
update_option( 'timezone_string', 'Europe/Moscow' );
update_option( 'permalink_structure', '/%postname%/' );
update_option( 'default_comment_status', 'closed' );
update_option( 'default_ping_status', 'closed' );
update_option( 'admin_email', 'demo@knife-market.test' );

foreach ( array( 'hello-world', 'sample-page' ) as $slug ) {
	$post = get_page_by_path( $slug, OBJECT, array( 'post', 'page' ) );
	if ( $post ) {
		wp_delete_post( $post->ID, true );
	}
}

/* ---------- WooCommerce ---------- */
if ( class_exists( 'WC_Install' ) && ! wc_get_page_id( 'shop' ) > 0 ) {
	WC_Install::create_pages();
}
$wc = array(
	'woocommerce_currency'                       => 'RUB',
	'woocommerce_default_country'                => 'RU',
	'woocommerce_currency_pos'                   => 'right_space',
	'woocommerce_price_thousand_sep'             => ' ',
	'woocommerce_price_decimal_sep'              => ',',
	'woocommerce_price_num_decimals'             => 0,
	'woocommerce_enable_reviews'                 => 'no',
	'woocommerce_coming_soon'                    => 'no',
	'woocommerce_allow_tracking'                 => 'no',
	'woocommerce_show_marketplace_suggestions'   => 'no',
	'woocommerce_default_catalog_orderby'        => 'date',
	'woocommerce_onboarding_profile'             => array( 'skipped' => true ),
	'woocommerce_task_list_hidden'               => 'yes',
	'woocommerce_extended_task_list_hidden'      => 'yes',
	'woocommerce_task_list_welcome_modal_dismissed' => 'yes',
	'woocommerce_cod_settings'                   => array( 'enabled' => 'yes', 'title' => 'Оплата при получении', 'description' => 'Демо-способ оплаты.' ),
);
foreach ( $wc as $k => $v ) {
	update_option( $k, $v );
}

/* ---------- Категории ---------- */
$cats = array(
	'skladnye-nozhi'       => 'Складные ножи',
	'fiksirovannyj-klinok' => 'Ножи с фиксированным клинком',
	'kuhonnye-nozhi'       => 'Кухонные ножи',
	'turizm'               => 'Туризм и снаряжение',
);
$term_ids = array();
foreach ( $cats as $slug => $name ) {
	$t = term_exists( $slug, 'product_cat' );
	if ( ! $t ) {
		$t = wp_insert_term( $name, 'product_cat', array( 'slug' => $slug ) );
	}
	$term_ids[ $slug ] = (int) ( is_array( $t ) ? $t['term_id'] : $t );
}
$un = get_term_by( 'slug', 'uncategorized', 'product_cat' );
if ( $un ) {
	wp_update_term( $un->term_id, 'product_cat', array( 'name' => 'Без категории', 'slug' => 'bez-kategorii' ) );
}

/* ---------- Заглушка «Фото скоро» ---------- */
$ph = km_sideload( 'km-placeholder-light.jpg', 'Заглушка: фото скоро' );
if ( $ph ) {
	update_option( 'woocommerce_placeholder_image', $ph );
}

/* ---------- Товары (цены — со страниц магазина на Wildberries, без WB Кошелька; пустая цена — заказчик пришлёт) ---------- */
$products = array(
	array( 'Нож складной Пчак туристический', 'nozh-skladnoj-pchak-turisticheskij', 'skladnye-nozhi', 1617, array( 'pchak-1', 'pchak-2', 'pchak-5' ) ),
	array( 'Нож танто охотничий в ножнах', 'nozh-tanto-ohotnichij-v-nozhnah', 'fiksirovannyj-klinok', 3307, array( 'tanto-1', 'tanto-2', 'tanto-3' ) ),
	array( 'Нож с фиксированным клинком «Охотник»', 'nozh-s-fiksirovannym-klinkom-ohotnik', 'fiksirovannyj-klinok', 2572, array( 'ohotnik-1', 'ohotnik-2', 'ohotnik-4' ) ),
	array( 'Нож охотничий тактический в ножнах', 'nozh-ohotnichij-takticheskij-v-nozhnah', 'fiksirovannyj-klinok', 1470, array( 'takt-1', 'takt-2', 'takt-4' ) ),
	array( 'Нож кухонный мини-шеф кованый', 'nozh-kuhonnyj-mini-shef-kovanyj', 'kuhonnye-nozhi', 1764, array( 'minishef-1', 'minishef-2', 'minishef-4' ) ),
	array( 'Мультитул с набором отвёрток', 'multitul-s-naborom-otvertok', 'turizm', 1323, array( 'multitul-1', 'multitul-2', 'multitul-3' ) ),
	array( 'Нож складной «Камень», сталь D2', 'nozh-skladnoj-kamen-stal-d2', 'skladnye-nozhi', 1543, array( 'nozh-skladnoj-kamen-stal-d2-1', 'nozh-skladnoj-kamen-stal-d2-2', 'nozh-skladnoj-kamen-stal-d2-3' ) ),
	array( 'Нож складной спиннер карманный', 'nozh-skladnoj-spinner-karmannyj', 'skladnye-nozhi', 735, array( 'nozh-skladnoj-spinner-karmannyj-1', 'nozh-skladnoj-spinner-karmannyj-5', 'nozh-skladnoj-spinner-karmannyj-2' ) ),
	array( 'Кухонный нож шеф, дамасская сталь', 'kuhonnyj-nozh-shef-damasskaya-stal', 'kuhonnye-nozhi', 0, array() ),
	array( 'Кухонный нож сантоку', 'kuhonnyj-nozh-santoku', 'kuhonnye-nozhi', 0, array() ),
	array( 'Топор туристический', 'topor-turisticheskij', 'turizm', 0, array() ),
	array( 'Фонарь налобный походный', 'fonar-nalobnyj-pohodnyj', 'turizm', 0, array() ),
);
$desc = "<!-- wp:paragraph -->\n<p>Демо-описание. Настоящий текст, характеристики (сталь, длина клинка, материал рукояти) и фото добавит заказчик.</p>\n<!-- /wp:paragraph -->";
$now  = time();
foreach ( $products as $i => $row ) {
	list( $name, $slug, $cat, $price, $images ) = $row;
	$p = new WC_Product_Simple();
	$p->set_name( $name );
	$p->set_slug( $slug );
	$p->set_status( 'publish' );
	$p->set_short_description( 'Демо-товар. Описание заполнит заказчик.' );
	$p->set_description( $desc );
	$p->set_category_ids( array( $term_ids[ $cat ] ) );
	if ( $price ) {
		$p->set_regular_price( (string) $price );
	}
	$pid = $p->save();
	$ids = array();
	foreach ( $images as $img ) {
		$aid = km_sideload( $img . '.webp', $name, $pid );
		if ( $aid ) {
			$ids[] = $aid;
		}
	}
	if ( $ids ) {
		$p->set_image_id( $ids[0] );
		$p->set_gallery_image_ids( array_slice( $ids, 1 ) );
		$p->save();
	}
	// Товары с фото — «новинки»: свежие даты, по убыванию.
	$d = gmdate( 'Y-m-d H:i:s', $now - 3600 * ( $i + 1 ) * ( $price ? 1 : 24 ) );
	wp_update_post( array( 'ID' => $pid, 'post_date_gmt' => $d, 'post_date' => get_date_from_gmt( $d ) ) );
}

/* ---------- Страницы ---------- */
$todo = 'km-todo';
$home = km_page( 'home', 'Главная', '' );
$tpl  = WP_CONTENT_DIR . '/themes/knife-market/patterns/home.php';
ob_start();
include $tpl;
wp_update_post( wp_slash( array( 'ID' => $home, 'post_content' => trim( ob_get_clean() ) ) ) );
update_option( 'show_on_front', 'page' );
update_option( 'page_on_front', $home );

km_page( 'catalog', 'Каталог', null, wc_get_page_id( 'shop' ) );
km_page( 'cart', 'Корзина', null, wc_get_page_id( 'cart' ) );
km_page( 'checkout', 'Оформление заказа', null, wc_get_page_id( 'checkout' ) );
km_page( 'my-account', 'Личный кабинет', null, wc_get_page_id( 'myaccount' ) );

km_page( 'about', 'О магазине', km_p( 'KNIFE MARKET — магазин ножей и снаряжения на Wildberries и Ozon.' ) . km_p( '[Рассказ о магазине: с какого года работаете, чем отличаетесь, кто стоит за магазином — текст пришлёт заказчик.]', $todo ) );
km_page( 'delivery', 'Доставка и оплата',
	km_h( 'Доставка' ) . km_p( '[Способы и сроки доставки, стоимость, регионы — уточнить у заказчика.]', $todo ) .
	km_h( 'Оплата' ) . km_p( '[Способы оплаты — уточнить у заказчика.]', $todo ) .
	km_p( 'Условия возврата — на странице <a href="/returns/">«Условия возврата»</a>.' ) );
km_page( 'contacts', 'Контакты',
	km_p( '[Телефон, e-mail, мессенджеры, адрес, часы работы — заполнит заказчик.]', $todo ) .
	km_h( 'Реквизиты' ) . km_p( '[ИП или ООО, ИНН, ОГРН — заполнит заказчик.]', $todo ) .
	km_h( 'Мы на маркетплейсах' ) .
	km_p( '<a href="https://www.wildberries.ru/seller/1203243" target="_blank" rel="noreferrer noopener">KNIFE MARKET на Wildberries</a>' ) .
	km_p( '<a href="https://ozon.ru/s/knife-market" target="_blank" rel="noreferrer noopener">KNIFE MARKET на Ozon</a>' ) );
// У WordPress уже есть своя заготовка страницы политики с тем же адресом — переписываем её, а не создаём вторую.
$privacy = km_page( 'privacy-policy', 'Политика конфиденциальности', km_p( '[Текст политики обработки персональных данных по 152-ФЗ: кто оператор, какие данные собираем, зачем, сколько храним, где хранятся (серверы в России), как отозвать согласие. Готовит юрист заказчика.]', $todo ), (int) get_option( 'wp_page_for_privacy_policy' ) );
update_option( 'wp_page_for_privacy_policy', $privacy );
$consent = km_page( 'consent', 'Согласие на обработку персональных данных', km_p( '[Текст согласия на обработку персональных данных — готовит юрист заказчика.]', $todo ) );
update_option( 'woocommerce_terms_page_id', $consent );

$warn = 'Черновик-шаблон. Требует проверки юристом заказчика до публикации. Значения в [квадратных скобках] заполняет заказчик.';
km_page( 'offer', 'Публичная оферта',
	km_p( $warn, $todo ) .
	km_h( '1. Стороны и реквизиты', 3 ) . km_p( 'Продавец: [полное наименование, ИНН, ОГРН/ОГРНИП, юридический адрес, телефон, e-mail — заполнит заказчик]. Покупатель — любое физическое лицо, оформившее заказ на сайте.' ) .
	km_h( '2. Предмет договора', 3 ) . km_p( 'Продавец обязуется передать Покупателю товар, выбранный в каталоге сайта, а Покупатель — оплатить и принять его.' ) .
	km_h( '3. Порядок заключения договора', 3 ) . km_p( 'Договор считается заключённым с момента оформления заказа на сайте (акцепт оферты). Нажимая «Оформить заказ», Покупатель принимает условия настоящей оферты.' ) .
	km_h( '4. Цена и порядок оплаты', 3 ) . km_p( '[Цены, валюта, способы оплаты — заполнит заказчик.]', $todo ) .
	km_h( '5. Сроки и способ передачи товара', 3 ) . km_p( '[Способы и сроки доставки, стоимость — заполнит заказчик.]', $todo ) .
	km_h( '6. Права и обязанности сторон', 3 ) . km_p( '[Заполнит заказчик с юристом.]', $todo ) .
	km_h( '7. Ответственность сторон', 3 ) . km_p( '[Заполнит заказчик с юристом.]', $todo ) .
	km_h( '8. Возврат товара', 3 ) . km_p( 'Порядок и сроки возврата изложены на странице <a href="/returns/">«Условия возврата»</a>.' ) .
	km_h( '9. Разрешение споров', 3 ) . km_p( '[Заполнит заказчик с юристом.]', $todo ) .
	km_h( '10. Срок действия', 3 ) . km_p( 'Оферта действует с момента публикации на сайте до её отзыва Продавцом. [Дата вступления в силу — заполнит заказчик.]' ) );
km_page( 'returns', 'Условия возврата',
	km_p( $warn, $todo ) .
	km_p( 'Информация о порядке возврата доступна до оформления заказа.' ) .
	km_h( 'Срок отказа от товара', 3 ) . km_p( 'До передачи товара — в любое время. После передачи — в течение 7 дней. Если порядок и сроки возврата не были доведены до Покупателя письменно при доставке, срок отказа — 3 месяца.' ) .
	km_h( 'Условия возврата', 3 ) . km_p( 'Товар не был в употреблении, сохранены товарный вид, потребительские свойства и документ об оплате.' ) .
	km_h( 'Возврат денег', 3 ) . km_p( 'Сумма возвращается не позднее 10 дней с момента предъявления требования, за вычетом расходов на доставку.' ) .
	km_h( 'Куда обращаться', 3 ) . km_p( '[Адрес для возврата, e-mail, форма заявления — заполнит заказчик.]', $todo ) );

// «Избранное»: все товары, скрипт показывает только отмеченные сердечком.
$fav = '<!-- wp:paragraph {"className":"km-fav-empty"} -->' . "\n" . '<p class="km-fav-empty">Здесь появятся товары, которые вы отметите сердечком.</p>' . "\n" . '<!-- /wp:paragraph -->' . "\n\n"
	. '<!-- wp:group {"className":"km-fav-list","layout":{"type":"default"}} -->' . "\n" . '<div class="wp-block-group km-fav-list"><!-- wp:woocommerce/product-collection {"queryId":31,"query":{"perPage":100,"pages":1,"offset":0,"postType":"product","order":"desc","orderBy":"date","search":"","exclude":[],"inherit":false,"taxQuery":[],"isProductCollectionBlock":true,"featured":false,"woocommerceOnSale":false,"woocommerceStockStatus":["instock","outofstock","onbackorder"],"woocommerceAttributes":[],"woocommerceHandPickedProducts":[]},"tagName":"div","displayLayout":{"type":"flex","columns":4,"shrinkColumns":true},"collection":"woocommerce/product-collection/product-catalog","hideControls":["inherit"]} -->' . "\n"
	. '<div class="wp-block-woocommerce-product-collection"><!-- wp:woocommerce/product-template -->' . "\n"
	. '<!-- wp:woocommerce/product-image {"showSaleBadge":false,"imageSizing":"thumbnail","isDescendentOfQueryLoop":true} /-->' . "\n\n"
	. '<!-- wp:post-title {"level":3,"isLink":true,"__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->' . "\n\n"
	. '<!-- wp:post-terms {"term":"product_cat","className":"km-card__sub"} /-->' . "\n\n"
	. '<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true} /-->' . "\n\n"
	. '<!-- wp:woocommerce/product-button {"isDescendentOfQueryLoop":true} /-->' . "\n"
	. '<!-- /wp:woocommerce/product-template --></div>' . "\n" . '<!-- /wp:woocommerce/product-collection --></div>' . "\n" . '<!-- /wp:group -->';
km_page( 'favorites', 'Избранное', $fav );

// Оформление заказа: галочка согласия на обработку персональных данных.
$co = wc_get_page_id( 'checkout' );
if ( $co > 0 ) {
	$c    = get_post_field( 'post_content', $co );
	$attr = wp_json_encode( array(
		'checkbox' => true,
		'text'     => 'Я даю <a href="/consent/" target="_blank">согласие на обработку персональных данных</a> и принимаю <a href="/privacy-policy/" target="_blank">политику конфиденциальности</a>',
	), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_QUOT );
	$new = preg_replace_callback( '/<!-- wp:woocommerce\/checkout-terms-block[^>]*-->/', function () use ( $attr ) {
		return "<!-- wp:woocommerce/checkout-terms-block $attr -->";
	}, $c, 1 );
	wp_update_post( array( 'ID' => $co, 'post_content' => wp_slash( $new ) ) );
}

/* ---------- Пользователь «Менеджер магазина» (под ним заказчик входит в админку) ---------- */
if ( ! username_exists( 'manager' ) ) {
	$uid = wp_insert_user( array(
		'user_login'   => 'manager',
		'user_pass'    => 'demo-manager',
		'user_email'   => 'manager@knife-market.test',
		'display_name' => 'Менеджер магазина',
		'role'         => 'shop_manager',
	) );
}

flush_rewrite_rules( true );
update_option( 'km_demo_seeded', time() );
